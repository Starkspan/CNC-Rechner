# CNC Preisrechner

Ein einfacher Datei-Upload und Preisrechner für CNC-Angebote.
Live auf GitHub Pages nutzbar.